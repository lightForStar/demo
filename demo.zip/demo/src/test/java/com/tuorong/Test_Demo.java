package com.tuorong;

import org.junit.Test;

/**
 * Created by Z先生 on 2019/11/9.
 */
public class Test_Demo extends DemoApplicationTests {


    @Test
    public void test(){
        System.out.println("可以测试");
    }

}
